// hooks/useApi.js
// Všechna komunikace s backendem

const API_URL = "https://adforge-api.YOUR-SUBDOMAIN.workers.dev";
// ↑ Sem vlož URL svého Cloudflare Workeru po deployi

export async function analyzeProduct(input, mode = "manual") {
  const res = await fetch(`${API_URL}/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ input, mode }),
  });
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.error || `Server error ${res.status}`);
  }
  return res.json(); // { product, competitors, strategy }
}

export async function generateAd(product, strategy, platform, format, tone) {
  const res = await fetch(`${API_URL}/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ product, strategy, platform, format, tone }),
  });
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.error || `Server error ${res.status}`);
  }
  const data = await res.json();
  return data.ad;
}

export async function getImagePrompt(product, adTitle, platform) {
  const res = await fetch(`${API_URL}/image-prompt`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ product, adTitle, platform }),
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.prompt;
}

export function getImageUrl(prompt) {
  if (!prompt) return null;
  const seed = Math.floor(Math.random() * 99999);
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1200&height=630&seed=${seed}&nologo=true`;
}
