// ============================================================
// AdForge Backend — Cloudflare Worker
// Deploy: https://workers.cloudflare.com (zdarma)
// 
// 1. Jdi na workers.cloudflare.com → Create Worker
// 2. Vlož tento kód
// 3. Settings → Variables → přidej GROQ_API_KEY = tvůj klíč z console.groq.com
// 4. Zkopíruj URL workeru do app.json → extra.API_URL
// ============================================================

export default {
  async fetch(request, env) {
    // CORS — povolí přístup z mobilní appky
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: cors });
    }

    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: cors });
    }

    const url = new URL(request.url);

    try {
      // ── /analyze ── analyze product + competitors + strategy
      if (url.pathname === "/analyze") {
        const { input, mode } = await request.json();

        const prompt = mode === "url"
          ? `Analyze this product/website: ${input}`
          : `Extract product info from: "${input}"`;

        const productRes = await groq(env.GROQ_API_KEY, `${prompt}

Return ONLY valid JSON, no markdown:
{
  "name": "product name",
  "tagline": "main tagline",
  "description": "2-3 sentences what it does",
  "target": "who it's for",
  "price": "pricing if known",
  "usp": ["key benefit 1", "key benefit 2", "key benefit 3"],
  "tone": "brand voice"
}`, 800);

        let product;
        try {
          const m = productRes.replace(/```json|```/gi, "").trim().match(/\{[\s\S]*\}/);
          product = JSON.parse(m[0]);
        } catch {
          product = { name: input, description: input, usp: [], tagline: "", tone: "professional" };
        }

        // Competitors
        const compRes = await groq(env.GROQ_API_KEY, `List 4 real competitors for: ${product.name} — ${product.description}

Return ONLY a JSON array, no markdown:
[{"name":"...","icon":"emoji","positioning":"one line","strengths":["s1","s2"],"gap":"what they miss","adStyle":"how they advertise"}]`, 1000);

        let competitors = [];
        try {
          const m = compRes.replace(/```json|```/gi, "").trim().match(/\[[\s\S]*\]/);
          competitors = JSON.parse(m[0]);
        } catch { competitors = []; }

        // Strategy
        const strategy = await groq(env.GROQ_API_KEY, `Write a 3-sentence differentiation strategy for: ${product.name} — ${product.description}
USPs: ${product.usp?.join(", ")}
Competitors: ${competitors.map(c => c.name).join(", ")}
What unique angle should ads use? What emotional hook? Be specific and punchy.`, 400);

        return new Response(JSON.stringify({ product, competitors, strategy }), { headers: cors });
      }

      // ── /generate ── generate ad copy
      if (url.pathname === "/generate") {
        const { product, strategy, platform, format, tone } = await request.json();

        const raw = await groq(env.GROQ_API_KEY, `You are a world-class performance marketer.

Product: ${product.name}
Description: ${product.description}
USPs: ${product.usp?.join(", ")}
Target: ${product.target || "general audience"}
Strategy: ${strategy}
Platform: ${platform}
Format: ${format}
Tone: ${tone}

Write 1 complete high-converting ad.

TITLE: [descriptive name]
PLATFORM: ${platform}
FORMAT: ${format}
ICON: [one emoji]
SCORE: [70-98]

${formatInstructions(format)}

TIP: [one tactical tip for best performance]`, 1200);

        const ad = parseAd(raw, platform, format);
        return new Response(JSON.stringify({ ad }), { headers: cors });
      }

      // ── /image-prompt ── get image gen prompt
      if (url.pathname === "/image-prompt") {
        const { product, adTitle, platform } = await request.json();
        const prompt = await groq(env.GROQ_API_KEY,
          `Write a 20-word image generation prompt for: ${product.name} ad titled "${adTitle}" for ${platform}. Professional advertising photo. No text in image. Return ONLY the prompt.`,
          80
        );
        return new Response(JSON.stringify({ prompt: prompt.trim() }), { headers: cors });
      }

      return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: cors });

    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: cors });
    }
  },
};

// ── Groq API call ──
async function groq(apiKey, prompt, maxTokens = 1000) {
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      max_tokens: maxTokens,
      temperature: 0.8,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.error?.message || `Groq ${res.status}`);
  }
  const d = await res.json();
  return d.choices?.[0]?.message?.content || "";
}

// ── Format instructions ──
function formatInstructions(format) {
  const map = {
    "Video Script": "[HOOK - 3 seconds]\n[PROBLEM - 5 seconds]\n[SOLUTION - 10 seconds]\n[SOCIAL PROOF - 5 seconds]\n[CTA - 3 seconds]",
    "Static Ad": "[HEADLINE]\n[SUBHEADLINE]\n[BODY COPY]\n[CTA BUTTON TEXT]",
    "Carousel": "Slide 1: [Hook]\nSlide 2: [Problem]\nSlide 3: [Solution]\nSlide 4: [Feature]\nSlide 5: [CTA]",
    "Story / Reel": "[HOOK - first frame]\n[QUICK VALUE]\n[CTA overlay]",
    "Search Ad": "Headline 1: [max 30 chars]\nHeadline 2: [max 30 chars]\nHeadline 3: [max 30 chars]\nDescription 1: [max 90 chars]\nDescription 2: [max 90 chars]",
    "Email Blast": "Subject: [compelling subject]\nPreview: [preview text]\n\n[Body with sections: Hook, Problem, Solution, Social proof, CTA]",
  };
  return map[format] || "[Full ad copy with clear sections]";
}

// ── Parse ad text ──
function parseAd(raw, platform, format) {
  const get = (key) => {
    const m = raw.match(new RegExp(`${key}:\\s*(.+)`, "i"));
    return m?.[1]?.trim() || "";
  };
  const score = parseInt(get("SCORE")) || 82;
  const headerEnd = raw.search(/\n\n/);
  const tipStart = raw.search(/\nTIP:/i);
  const content = raw.slice(headerEnd > -1 ? headerEnd : 0, tipStart > -1 ? tipStart : undefined).trim();
  return {
    title: get("TITLE") || "Ad",
    platform: get("PLATFORM") || platform,
    format: get("FORMAT") || format,
    icon: get("ICON") || "📢",
    score,
    content,
    tip: get("TIP") || "",
  };
}
