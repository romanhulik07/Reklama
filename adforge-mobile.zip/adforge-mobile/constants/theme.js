// constants/theme.js
export const colors = {
  bg: "#08080e",
  surface: "#0f0f18",
  surfaceHigh: "#14141f",
  border: "rgba(255,255,255,0.07)",
  borderActive: "rgba(255,61,0,0.4)",
  accent: "#ff3d00",
  accentDim: "rgba(255,61,0,0.12)",
  text: "#f0ece4",
  textMuted: "#666",
  textDim: "#444",
  success: "#27c93f",
  warning: "#f5c542",
  mono: "SpaceMono",
};

export const fonts = {
  display: "System", // replace with custom font if needed
  body: "System",
};

export const radius = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 20,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};
