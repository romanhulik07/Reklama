# AdForge Mobile — Kompletní průvodce nasazením

## Architektura

```
[Uživatel - telefon]
       ↓
[React Native Expo app]
       ↓ (HTTPS, bez API klíče)
[Cloudflare Worker - tvůj server]
       ↓ (API klíč na serveru)
[Groq API - Llama 3.3 70B]
       ↓
[Pollinations.ai - obrázky zdarma]
```

Uživatel NIKDY nevidí API klíče. Vše je na tvém serveru.

---

## KROK 1 — Backend (Cloudflare Worker)

### 1.1 Vytvoř účet
- Jdi na https://workers.cloudflare.com
- Registruj se zdarma (žádná kreditní karta)

### 1.2 Vytvoř Worker
1. Dashboard → Workers & Pages → Create
2. Vyber "Create Worker"
3. Pojmenuj ho `adforge-api`
4. Klikni "Edit code"
5. Vymaž vše a vlož obsah ze souboru `backend/worker.js`
6. Klikni "Deploy"

### 1.3 Přidej API klíč (bezpečně)
1. Jdi na Worker → Settings → Variables
2. Klikni "Add variable"
3. Name: `GROQ_API_KEY`
4. Value: tvůj klíč z https://console.groq.com/keys
5. Zaškrtni "Encrypt" ← důležité!
6. Klikni Save

### 1.4 Zkopíruj URL
- URL tvého workeru bude: `https://adforge-api.YOUR-NAME.workers.dev`
- Zkopíruj ji — budeš ji potřebovat v dalším kroku

### Limity zdarma
- 100,000 requestů/den
- Groq: 14,400 API callů/den (cca 2,400 kampaní)
- Pollinations: neomezeno

---

## KROK 2 — Mobilní app

### 2.1 Instalace
```bash
npm install -g @expo/cli eas-cli

cd adforge-mobile
npm install
```

### 2.2 Nastav URL backendu
Otevři soubor `hooks/useApi.js` a nahraď:
```js
const API_URL = "https://adforge-api.YOUR-SUBDOMAIN.workers.dev";
```
svou skutečnou URL z Kroku 1.

Také v `app.json`:
```json
"extra": {
  "API_URL": "https://adforge-api.TVOJE-URL.workers.dev"
}
```

### 2.3 Testování lokálně
```bash
npx expo start
```
- Naskenuj QR kód v Expo Go appce (stáhnout z App Store / Play Store)
- App běží přímo na tvém telefonu

---

## KROK 3 — Publikace do App Store / Google Play

### 3.1 Přihlášení do EAS
```bash
eas login
eas build:configure
```

### 3.2 Build pro Android (APK/AAB)
```bash
eas build --platform android --profile preview
```
- Stáhneš .apk soubor který rovnou nasdílíš
- NEBO pro Google Play: `--profile production`

### 3.3 Build pro iOS (IPA)
```bash
eas build --platform ios
```
- Potřebuješ Apple Developer účet ($99/rok)
- Pro testování bez App Store použij TestFlight

### 3.4 Přímý APK (Android bez Play Store)
```bash
eas build --platform android --profile preview
```
Vygeneruje APK který lidé stáhnou přímo z webu.
Sdílíš odkaz na download — žádný App Store potřeba.

---

## Struktura souborů

```
adforge-mobile/
├── app/
│   ├── _layout.jsx        # Root layout
│   ├── index.jsx          # Úvodní obrazovka (zadání produktu)
│   ├── configure.jsx      # Výběr platforem, formátů, tónu
│   └── results.jsx        # Výsledky: reklamy, strategie, konkurence
├── backend/
│   └── worker.js          # Cloudflare Worker (deployuj toto)
├── hooks/
│   └── useApi.js          # API volání (nastav API_URL zde)
├── constants/
│   └── theme.js           # Barvy, spacing, design tokeny
├── app.json               # Expo konfigurace
└── package.json           # Závislosti
```

---

## Flow aplikace

1. **Úvodní obrazovka** → zadáš URL nebo popis produktu
2. **Backend analyzuje** → produkt, 4 konkurenti, strategie
3. **Konfigurace** → vybereš platformy + formáty + tón
4. **Generování** → postupně generuje reklamy (1 za 1)
5. **Výsledky** → 3 záložky: Reklamy | Strategie | Konkurence
   - Každá reklama má AI vizuál, copy, tip
   - Kopírovat / Sdílet / Export vše

---

## Časté problémy

### "Network request failed"
→ Zkontroluj URL v `hooks/useApi.js`
→ Zkontroluj že Worker je nasazený a dostupný

### "GROQ_API_KEY not found"
→ Přidej Environment Variable v Cloudflare Workers dashboard

### App se nezobrazuje správně
→ Spusť `npx expo start --clear`

### Build selže
→ `eas build --platform android --clear-cache`

---

## Rozšíření (volitelné)

- **Supabase** → ukládání kampaní, user accounts
- **RevenueCat** → in-app platby, premium tier
- **Firebase Analytics** → sledování usage
- **Více modelů** → přidat Gemini jako fallback v worker.js
