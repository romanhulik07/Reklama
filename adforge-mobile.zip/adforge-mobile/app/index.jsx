// app/index.jsx  — Úvodní obrazovka
import { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { analyzeProduct } from "../hooks/useApi";
import { colors, spacing, radius } from "../constants/theme";

const FEATURES = [
  { icon: "🔍", title: "Analýza produktu", desc: "AI přečte tvůj web a pochopí produkt" },
  { icon: "🏆", title: "Průzkum konkurence", desc: "Identifikuje slabiny konkurentů" },
  { icon: "🧠", title: "Strategie", desc: "Navrhne jak se odlišit" },
  { icon: "🎨", title: "Reklamy + vizuály", desc: "Hotové texty a AI obrázky" },
];

export default function HomeScreen() {
  const router = useRouter();
  const [mode, setMode] = useState("url");
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const data = await analyzeProduct(input.trim(), mode);
      // Navigate to config screen with data
      router.push({
        pathname: "/configure",
        params: {
          productData: JSON.stringify(data.product),
          competitorsData: JSON.stringify(data.competitors),
          strategy: data.strategy,
        },
      });
    } catch (e) {
      Alert.alert("Chyba", e.message || "Nepodařilo se analyzovat produkt. Zkus znovu.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.logo}>AD<Text style={styles.logoAccent}>FORGE</Text></Text>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>AI ENGINE</Text>
            </View>
          </View>

          {/* Hero */}
          <View style={styles.hero}>
            <LinearGradient
              colors={["rgba(255,61,0,0.15)", "transparent"]}
              style={styles.heroBg}
            />
            <Text style={styles.heroLabel}>GENERÁTOR REKLAM</Text>
            <Text style={styles.heroTitle}>Zadej produkt.{"\n"}Dostaneš kampaň.</Text>
            <Text style={styles.heroSub}>
              AI analyzuje tvůj web, porovná konkurenci a vygeneruje hotové reklamy se snímky.
            </Text>
          </View>

          {/* Mode toggle */}
          <View style={styles.modeToggle}>
            {[["url", "🔗 URL webu"], ["manual", "✏️ Popis"]].map(([m, label]) => (
              <TouchableOpacity
                key={m}
                style={[styles.modeBtn, mode === m && styles.modeBtnActive]}
                onPress={() => setMode(m)}
              >
                <Text style={[styles.modeBtnText, mode === m && styles.modeBtnTextActive]}>
                  {label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Input */}
          <View style={styles.inputWrap}>
            <TextInput
              style={styles.input}
              value={input}
              onChangeText={setInput}
              placeholder={
                mode === "url"
                  ? "https://tvujprodukt.cz"
                  : "Popiš produkt — co to je, pro koho, cena, výhody..."
              }
              placeholderTextColor={colors.textDim}
              multiline={mode === "manual"}
              numberOfLines={mode === "manual" ? 4 : 1}
              autoCapitalize="none"
              keyboardType={mode === "url" ? "url" : "default"}
              returnKeyType={mode === "url" ? "go" : "default"}
              onSubmitEditing={mode === "url" ? handleGenerate : undefined}
            />
          </View>

          {/* CTA */}
          <TouchableOpacity
            style={[styles.cta, (!input.trim() || loading) && styles.ctaDisabled]}
            onPress={handleGenerate}
            disabled={!input.trim() || loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <View style={styles.ctaInner}>
                <ActivityIndicator color="#fff" size="small" />
                <Text style={styles.ctaText}>Analyzuji...</Text>
              </View>
            ) : (
              <Text style={styles.ctaText}>⚡ Analyzovat a generovat kampaň</Text>
            )}
          </TouchableOpacity>

          <Text style={styles.ctaNote}>Zdarma · Žádná registrace · Výsledky za minutu</Text>

          {/* Features */}
          <View style={styles.features}>
            {FEATURES.map((f) => (
              <View key={f.title} style={styles.featureCard}>
                <Text style={styles.featureIcon}>{f.icon}</Text>
                <Text style={styles.featureTitle}>{f.title}</Text>
                <Text style={styles.featureDesc}>{f.desc}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  scroll: { flex: 1 },
  content: { padding: spacing.md, paddingBottom: spacing.xxl },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.xl },
  logo: { fontSize: 28, fontWeight: "900", letterSpacing: 4, color: colors.text },
  logoAccent: { color: colors.accent },
  badge: { backgroundColor: "rgba(255,255,255,0.05)", borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1, borderColor: colors.border },
  badgeText: { fontSize: 9, color: colors.textDim, letterSpacing: 2, fontFamily: "monospace" },
  hero: { borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.xl, overflow: "hidden", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  heroBg: { position: "absolute", top: 0, left: 0, right: 0, height: 120 },
  heroLabel: { fontSize: 10, color: colors.accent, letterSpacing: 3, fontFamily: "monospace", marginBottom: spacing.sm },
  heroTitle: { fontSize: 32, fontWeight: "900", color: colors.text, lineHeight: 36, marginBottom: spacing.sm },
  heroSub: { fontSize: 14, color: colors.textMuted, lineHeight: 20 },
  modeToggle: { flexDirection: "row", backgroundColor: colors.surface, borderRadius: radius.md, padding: 4, marginBottom: spacing.md, borderWidth: 1, borderColor: colors.border },
  modeBtn: { flex: 1, paddingVertical: 10, borderRadius: radius.sm, alignItems: "center" },
  modeBtnActive: { backgroundColor: colors.accent },
  modeBtnText: { fontSize: 13, color: colors.textMuted, fontFamily: "monospace" },
  modeBtnTextActive: { color: "#fff", fontWeight: "600" },
  inputWrap: { marginBottom: spacing.md },
  input: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, color: colors.text, fontSize: 15, minHeight: 52, textAlignVertical: "top" },
  cta: { backgroundColor: colors.accent, borderRadius: radius.md, paddingVertical: 18, alignItems: "center", marginBottom: spacing.sm },
  ctaDisabled: { backgroundColor: "#1a1a1a" },
  ctaInner: { flexDirection: "row", gap: 10, alignItems: "center" },
  ctaText: { color: "#fff", fontSize: 15, fontWeight: "700", letterSpacing: 1 },
  ctaNote: { textAlign: "center", fontSize: 12, color: colors.textDim, marginBottom: spacing.xl },
  features: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  featureCard: { flex: 1, minWidth: "45%", backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.md, borderWidth: 1, borderColor: colors.border },
  featureIcon: { fontSize: 24, marginBottom: spacing.sm },
  featureTitle: { fontSize: 13, fontWeight: "600", color: colors.text, marginBottom: 4 },
  featureDesc: { fontSize: 12, color: colors.textMuted, lineHeight: 17 },
});
