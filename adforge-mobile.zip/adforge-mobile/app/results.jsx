// app/results.jsx — Výsledky kampaně
import { useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Image, Share, Alert,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import * as Clipboard from "expo-clipboard";
import { colors, spacing, radius } from "../constants/theme";

function AdCard({ ad, index }) {
  const [copied, setCopied] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgErr, setImgErr] = useState(false);

  const handleCopy = async () => {
    await Clipboard.setStringAsync(ad.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `${ad.title}\n${ad.platform} · ${ad.format}\n\n${ad.content}${ad.tip ? `\n\n💡 ${ad.tip}` : ""}`,
        title: ad.title,
      });
    } catch (e) { /* ignore */ }
  };

  return (
    <View style={styles.adCard}>
      {/* Image */}
      {ad.imageUrl && !imgErr && (
        <View style={styles.adImageWrap}>
          {!imgLoaded && (
            <View style={styles.imgPlaceholder}>
              <Text style={styles.imgPlaceholderText}>🎨 Generuji vizuál...</Text>
            </View>
          )}
          <Image
            source={{ uri: ad.imageUrl }}
            style={[styles.adImage, !imgLoaded && { height: 0 }]}
            onLoad={() => setImgLoaded(true)}
            onError={() => setImgErr(true)}
            resizeMode="cover"
          />
          <View style={styles.adImageBadges}>
            <View style={styles.platformBadge}>
              <Text style={styles.platformBadgeText}>{ad.platform}</Text>
            </View>
            <View style={styles.formatBadge}>
              <Text style={styles.formatBadgeText}>{ad.format}</Text>
            </View>
          </View>
        </View>
      )}

      {/* Header */}
      <View style={styles.adHeader}>
        <View style={styles.adHeaderLeft}>
          <Text style={styles.adIcon}>{ad.icon || "📢"}</Text>
          <View>
            <Text style={styles.adTitle}>{ad.title}</Text>
            {!ad.imageUrl && (
              <Text style={styles.adMeta}>{ad.platform} · {ad.format}</Text>
            )}
          </View>
        </View>
        <View style={styles.adHeaderRight}>
          {ad.score && (
            <View style={[styles.scoreBadge, { backgroundColor: ad.score >= 85 ? "rgba(39,201,63,0.12)" : "rgba(245,197,66,0.12)" }]}>
              <Text style={[styles.scoreText, { color: ad.score >= 85 ? colors.success : colors.warning }]}>
                {ad.score}
              </Text>
            </View>
          )}
        </View>
      </View>

      {/* Content */}
      <View style={styles.adBody}>
        <Text style={styles.adContent}>{ad.content}</Text>
        {ad.tip && (
          <View style={styles.tipBox}>
            <Text style={styles.tipText}>💡 {ad.tip}</Text>
          </View>
        )}
      </View>

      {/* Actions */}
      <View style={styles.adActions}>
        <TouchableOpacity style={styles.actionBtn} onPress={handleCopy}>
          <Text style={[styles.actionBtnText, copied && { color: colors.success }]}>
            {copied ? "✓ Zkopírováno" : "📋 Kopírovat"}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionBtn, styles.actionBtnPrimary]} onPress={handleShare}>
          <Text style={styles.actionBtnPrimaryText}>↗ Sdílet</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function ResultsScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const ads = JSON.parse(params.adsData || "[]");
  const product = JSON.parse(params.productData || "{}");
  const competitors = JSON.parse(params.competitorsData || "[]");
  const strategy = params.strategy || "";

  const [activeTab, setActiveTab] = useState("reklamy");

  const handleExport = async () => {
    const txt = [
      `ADFORGE KAMPAŇ`,
      `═══════════════════════════`,
      `Produkt: ${product.name}`,
      `${product.description || ""}`,
      ``,
      `STRATEGIE:`,
      strategy,
      ``,
      `REKLAMY:`,
      `───────────────────────────`,
      ...ads.map(a => `[${a.platform} · ${a.format}]\n${a.title}\n\n${a.content}${a.tip ? `\n\n💡 ${a.tip}` : ""}`),
    ].join("\n\n");

    await Share.share({ message: txt, title: "AdForge kampaň" });
  };

  const tabs = ["reklamy", "strategie", "konkurence"];

  return (
    <SafeAreaView style={styles.safe}>
      {/* Fixed header */}
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => router.push("/")} style={styles.backBtn}>
          <Text style={styles.backText}>← Nová</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>AD<Text style={{ color: colors.accent }}>FORGE</Text></Text>
        <TouchableOpacity onPress={handleExport} style={styles.exportBtn}>
          <Text style={styles.exportText}>↗ Export</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        {tabs.map(t => (
          <TouchableOpacity key={t} style={[styles.tab, activeTab === t && styles.tabActive]} onPress={() => setActiveTab(t)}>
            <Text style={[styles.tabText, activeTab === t && styles.tabTextActive]}>
              {t === "reklamy" ? `Reklamy (${ads.length})` : t.charAt(0).toUpperCase() + t.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* REKLAMY */}
        {activeTab === "reklamy" && (
          <View>
            <View style={styles.successBanner}>
              <Text style={styles.successText}>✓ {ads.length} reklam vygenerováno</Text>
            </View>
            {ads.map((ad, i) => <AdCard key={i} ad={ad} index={i} />)}
          </View>
        )}

        {/* STRATEGIE */}
        {activeTab === "strategie" && (
          <View>
            {/* Product */}
            <View style={styles.productCard}>
              <Text style={styles.cardLabel}>PRODUKT</Text>
              <Text style={styles.productName}>{product.name}</Text>
              {product.tagline && <Text style={styles.productTagline}>"{product.tagline}"</Text>}
              <Text style={styles.productDesc}>{product.description}</Text>
              <View style={styles.uspRow}>
                {(product.usp || []).map((u, i) => (
                  <View key={i} style={styles.uspBadge}>
                    <Text style={styles.uspText}>✓ {u}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Strategy */}
            <View style={styles.strategyCard}>
              <Text style={styles.cardLabel}>🧠 DIFERENCIAČNÍ STRATEGIE</Text>
              <Text style={styles.strategyText}>{strategy}</Text>
            </View>
          </View>
        )}

        {/* KONKURENCE */}
        {activeTab === "konkurence" && (
          <View>
            <Text style={styles.compIntro}>
              Analýza {competitors.length} hlavních konkurentů a jejich mezer.
            </Text>
            {competitors.map((c, i) => (
              <View key={i} style={styles.compCard}>
                <View style={styles.compHeader}>
                  <Text style={styles.compIcon}>{c.icon}</Text>
                  <View style={styles.compHeaderText}>
                    <Text style={styles.compName}>{c.name}</Text>
                    <Text style={styles.compPositioning}>{c.positioning}</Text>
                  </View>
                </View>
                <View style={styles.compStrengths}>
                  {(c.strengths || []).map((s, j) => (
                    <View key={j} style={styles.strengthBadge}>
                      <Text style={styles.strengthText}>✓ {s}</Text>
                    </View>
                  ))}
                </View>
                <View style={styles.compGap}>
                  <Text style={styles.compGapLabel}>Gap (tvoje příležitost):</Text>
                  <Text style={styles.compGapText}>{c.gap}</Text>
                </View>
                {c.adStyle && (
                  <Text style={styles.compAdStyle}>Reklamní styl: {c.adStyle}</Text>
                )}
              </View>
            ))}
          </View>
        )}

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  topBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.md, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
  backBtn: {},
  backText: { color: colors.textMuted, fontSize: 13, fontFamily: "monospace" },
  topTitle: { fontSize: 20, fontWeight: "900", letterSpacing: 3, color: colors.text },
  exportBtn: { backgroundColor: colors.accentDim, borderRadius: radius.sm, paddingHorizontal: 12, paddingVertical: 6, borderWidth: 1, borderColor: "rgba(255,61,0,0.3)" },
  exportText: { color: colors.accent, fontSize: 12, fontFamily: "monospace" },
  tabs: { flexDirection: "row", borderBottomWidth: 1, borderBottomColor: colors.border },
  tab: { flex: 1, paddingVertical: 12, alignItems: "center" },
  tabActive: { borderBottomWidth: 2, borderBottomColor: colors.accent },
  tabText: { fontSize: 12, color: colors.textMuted, fontFamily: "monospace", textTransform: "uppercase", letterSpacing: 1 },
  tabTextActive: { color: colors.accent },
  scroll: { flex: 1 },
  content: { padding: spacing.md, paddingBottom: 60 },
  successBanner: { backgroundColor: "rgba(39,201,63,0.07)", borderWidth: 1, borderColor: "rgba(39,201,63,0.2)", borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md, alignItems: "center" },
  successText: { color: colors.success, fontSize: 13, fontFamily: "monospace" },
  // Ad card
  adCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, marginBottom: spacing.md, overflow: "hidden" },
  adImageWrap: { position: "relative" },
  adImage: { width: "100%", height: 200 },
  imgPlaceholder: { height: 120, alignItems: "center", justifyContent: "center", backgroundColor: "#0a0a12" },
  imgPlaceholderText: { fontSize: 13, color: colors.textDim },
  adImageBadges: { position: "absolute", bottom: 8, left: 10, flexDirection: "row", gap: 6 },
  platformBadge: { backgroundColor: colors.accent, borderRadius: 3, paddingHorizontal: 7, paddingVertical: 2 },
  platformBadgeText: { color: "#fff", fontSize: 9, fontFamily: "monospace", letterSpacing: 1 },
  formatBadge: { backgroundColor: "rgba(0,0,0,0.6)", borderRadius: 3, paddingHorizontal: 7, paddingVertical: 2 },
  formatBadgeText: { color: "#ccc", fontSize: 9, fontFamily: "monospace" },
  adHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: spacing.md, borderBottomWidth: 1, borderBottomColor: "rgba(255,255,255,0.04)" },
  adHeaderLeft: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  adHeaderRight: { flexDirection: "row", gap: 6, alignItems: "center" },
  adIcon: { fontSize: 20 },
  adTitle: { fontSize: 13, fontWeight: "600", color: colors.text },
  adMeta: { fontSize: 10, color: colors.textDim, fontFamily: "monospace", textTransform: "uppercase", letterSpacing: 1, marginTop: 2 },
  scoreBadge: { borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 3 },
  scoreText: { fontSize: 11, fontFamily: "monospace", letterSpacing: 1 },
  adBody: { padding: spacing.md },
  adContent: { fontSize: 14, color: "#a8a4a0", lineHeight: 22 },
  tipBox: { marginTop: 10, borderLeftWidth: 2, borderLeftColor: colors.accent, backgroundColor: colors.accentDim, borderRadius: "0 6px 6px 0", padding: spacing.sm },
  tipText: { fontSize: 12, color: "#ff7a5a", lineHeight: 18 },
  adActions: { flexDirection: "row", gap: 8, padding: spacing.md, paddingTop: 0 },
  actionBtn: { flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, paddingVertical: 10, alignItems: "center", backgroundColor: "rgba(255,255,255,0.03)" },
  actionBtnText: { fontSize: 13, color: colors.textMuted },
  actionBtnPrimary: { backgroundColor: colors.accentDim, borderColor: "rgba(255,61,0,0.3)" },
  actionBtnPrimaryText: { fontSize: 13, color: colors.accent, fontWeight: "600" },
  // Strategy
  productCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: "rgba(255,61,0,0.15)", borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.md },
  cardLabel: { fontSize: 10, color: colors.accent, letterSpacing: 3, fontFamily: "monospace", marginBottom: spacing.sm },
  productName: { fontSize: 18, fontWeight: "700", color: colors.text, marginBottom: 4 },
  productTagline: { fontSize: 13, color: colors.textMuted, fontStyle: "italic", marginBottom: spacing.sm },
  productDesc: { fontSize: 13, color: colors.textMuted, lineHeight: 19, marginBottom: spacing.sm },
  uspRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  uspBadge: { backgroundColor: colors.accentDim, borderRadius: radius.sm, paddingHorizontal: 9, paddingVertical: 3 },
  uspText: { fontSize: 11, color: "#ff7050", fontFamily: "monospace" },
  strategyCard: { backgroundColor: "#0a0a12", borderWidth: 1, borderColor: "rgba(245,197,66,0.15)", borderRadius: radius.lg, padding: spacing.md },
  strategyText: { fontSize: 14, color: "#b0aba5", lineHeight: 22 },
  // Competitors
  compIntro: { fontSize: 13, color: colors.textMuted, marginBottom: spacing.md, lineHeight: 18 },
  compCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.md },
  compHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: spacing.sm },
  compIcon: { fontSize: 24 },
  compHeaderText: { flex: 1 },
  compName: { fontSize: 14, fontWeight: "600", color: colors.text },
  compPositioning: { fontSize: 12, color: colors.textDim, marginTop: 2 },
  compStrengths: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: spacing.sm },
  strengthBadge: { backgroundColor: "rgba(39,201,63,0.07)", borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 3 },
  strengthText: { fontSize: 11, color: colors.success, fontFamily: "monospace" },
  compGap: { backgroundColor: "rgba(255,61,0,0.07)", borderRadius: radius.sm, padding: spacing.sm, marginBottom: 6 },
  compGapLabel: { fontSize: 10, color: colors.textDim, fontFamily: "monospace", marginBottom: 3 },
  compGapText: { fontSize: 13, color: "#ff7050" },
  compAdStyle: { fontSize: 12, color: colors.textDim, fontStyle: "italic" },
});
