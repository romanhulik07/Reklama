// app/configure.jsx — Výběr platforem a formátů
import { useState } from "react";
import {
  View, Text, TouchableOpacity, ScrollView,
  StyleSheet, Alert,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { generateAd, getImagePrompt, getImageUrl } from "../hooks/useApi";
import { colors, spacing, radius } from "../constants/theme";

const PLATFORMS = [
  { id: "meta", label: "Meta / Facebook", icon: "📘" },
  { id: "instagram", label: "Instagram", icon: "📸" },
  { id: "tiktok", label: "TikTok", icon: "🎵" },
  { id: "google", label: "Google Search", icon: "🔍" },
  { id: "linkedin", label: "LinkedIn", icon: "💼" },
  { id: "email", label: "Email", icon: "📧" },
];

const FORMATS = [
  { id: "video", label: "Video Script", icon: "🎬" },
  { id: "static", label: "Static Ad", icon: "🖼️" },
  { id: "carousel", label: "Carousel", icon: "🎠" },
  { id: "story", label: "Story / Reel", icon: "⚡" },
  { id: "search", label: "Search Ad", icon: "🔍" },
  { id: "email", label: "Email Blast", icon: "📧" },
];

const TONES = ["Urgent & Direct", "Friendly & Warm", "Premium", "Bold & Provocative", "Educational"];

export default function ConfigureScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const product = JSON.parse(params.productData || "{}");
  const competitors = JSON.parse(params.competitorsData || "[]");
  const strategy = params.strategy || "";

  const [platforms, setPlatforms] = useState(["meta", "tiktok"]);
  const [formats, setFormats] = useState(["video", "static"]);
  const [tone, setTone] = useState("Urgent & Direct");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0, label: "" });

  const toggle = (arr, setArr, id) =>
    setArr(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  const handleGenerate = async () => {
    if (platforms.length === 0 || formats.length === 0) {
      Alert.alert("Vyber platformy a formáty");
      return;
    }

    setLoading(true);
    const total = platforms.length * formats.length;
    const allAds = [];

    try {
      let i = 0;
      for (const platformId of platforms) {
        const platform = PLATFORMS.find(p => p.id === platformId)?.label || platformId;
        for (const formatId of formats) {
          const format = FORMATS.find(f => f.id === formatId)?.label || formatId;
          i++;
          setProgress({ current: i, total, label: `${platform} · ${format}` });

          try {
            const ad = await generateAd(product, strategy, platform, format, tone);

            // Get image
            try {
              const imgPrompt = await getImagePrompt(product, ad.title, platform);
              ad.imageUrl = getImageUrl(imgPrompt);
            } catch { ad.imageUrl = null; }

            allAds.push(ad);
          } catch (e) {
            console.warn(`Failed ${platform}/${format}:`, e.message);
          }
        }
      }

      if (allAds.length === 0) {
        throw new Error("Nepodařilo se vygenerovat žádnou reklamu.");
      }

      router.push({
        pathname: "/results",
        params: {
          adsData: JSON.stringify(allAds),
          productData: JSON.stringify(product),
          competitorsData: JSON.stringify(competitors),
          strategy,
        },
      });
    } catch (e) {
      Alert.alert("Chyba", e.message);
    } finally {
      setLoading(false);
    }
  };

  const count = platforms.length * formats.length;

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Back + title */}
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Zpět</Text>
        </TouchableOpacity>

        <Text style={styles.stepLabel}>NASTAVENÍ KAMPANĚ</Text>
        <Text style={styles.title}>Kde & Jak</Text>

        {/* Product pill */}
        <View style={styles.productPill}>
          <Text style={styles.productName}>{product.name}</Text>
          <Text style={styles.productDesc} numberOfLines={2}>{product.description}</Text>
        </View>

        {/* Platforms */}
        <Text style={styles.sectionLabel}>PLATFORMY</Text>
        <View style={styles.grid}>
          {PLATFORMS.map(p => (
            <TouchableOpacity
              key={p.id}
              style={[styles.chip, platforms.includes(p.id) && styles.chipActive]}
              onPress={() => toggle(platforms, setPlatforms, p.id)}
            >
              <Text style={styles.chipIcon}>{p.icon}</Text>
              <Text style={[styles.chipLabel, platforms.includes(p.id) && styles.chipLabelActive]}>
                {p.label}
              </Text>
              {platforms.includes(p.id) && <Text style={styles.chipCheck}>✓</Text>}
            </TouchableOpacity>
          ))}
        </View>

        {/* Formats */}
        <Text style={styles.sectionLabel}>FORMÁTY</Text>
        <View style={styles.grid}>
          {FORMATS.map(f => (
            <TouchableOpacity
              key={f.id}
              style={[styles.chip, formats.includes(f.id) && styles.chipActive]}
              onPress={() => toggle(formats, setFormats, f.id)}
            >
              <Text style={styles.chipIcon}>{f.icon}</Text>
              <Text style={[styles.chipLabel, formats.includes(f.id) && styles.chipLabelActive]}>
                {f.label}
              </Text>
              {formats.includes(f.id) && <Text style={styles.chipCheck}>✓</Text>}
            </TouchableOpacity>
          ))}
        </View>

        {/* Tone */}
        <Text style={styles.sectionLabel}>TÓN & HLAS</Text>
        <View style={styles.toneRow}>
          {TONES.map(t => (
            <TouchableOpacity
              key={t}
              style={[styles.toneChip, tone === t && styles.toneChipActive]}
              onPress={() => setTone(t)}
            >
              <Text style={[styles.toneText, tone === t && styles.toneTextActive]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Summary */}
        <View style={styles.summary}>
          <Text style={styles.summaryText}>
            Vygeneruje <Text style={styles.summaryBold}>{count}</Text> reklam ·{" "}
            <Text style={styles.summaryBold}>{platforms.length}</Text> platf. ×{" "}
            <Text style={styles.summaryBold}>{formats.length}</Text> formátů
          </Text>
        </View>

        {/* Loading progress */}
        {loading && (
          <View style={styles.progressBox}>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${(progress.current / progress.total) * 100}%` }]} />
            </View>
            <Text style={styles.progressLabel}>
              {progress.current}/{progress.total} · {progress.label}
            </Text>
          </View>
        )}

        {/* CTA */}
        <TouchableOpacity
          style={[styles.cta, (loading || count === 0) && styles.ctaDisabled]}
          onPress={handleGenerate}
          disabled={loading || count === 0}
          activeOpacity={0.85}
        >
          <Text style={styles.ctaText}>
            {loading ? `Generuji ${progress.current}/${progress.total}...` : `⚡ Generovat ${count} reklam`}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  scroll: { flex: 1 },
  content: { padding: spacing.md, paddingBottom: 60 },
  backBtn: { marginBottom: spacing.md },
  backText: { color: colors.textMuted, fontSize: 14, fontFamily: "monospace" },
  stepLabel: { fontSize: 10, color: colors.accent, letterSpacing: 3, fontFamily: "monospace", marginBottom: 6 },
  title: { fontSize: 38, fontWeight: "900", color: colors.text, marginBottom: spacing.lg },
  productPill: { backgroundColor: "rgba(255,61,0,0.07)", borderWidth: 1, borderColor: "rgba(255,61,0,0.2)", borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.xl },
  productName: { fontSize: 15, fontWeight: "700", color: colors.text, marginBottom: 4 },
  productDesc: { fontSize: 13, color: colors.textMuted, lineHeight: 18 },
  sectionLabel: { fontSize: 10, color: colors.textDim, letterSpacing: 2, fontFamily: "monospace", marginBottom: 10, marginTop: spacing.md },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: spacing.md },
  chip: { flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.xl, paddingHorizontal: 12, paddingVertical: 9 },
  chipActive: { backgroundColor: colors.accentDim, borderColor: "rgba(255,61,0,0.4)" },
  chipIcon: { fontSize: 16 },
  chipLabel: { fontSize: 12, color: colors.textMuted },
  chipLabelActive: { color: "#ff7050" },
  chipCheck: { fontSize: 11, color: colors.accent, marginLeft: 2 },
  toneRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: spacing.lg },
  toneChip: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.xl, paddingHorizontal: 14, paddingVertical: 8 },
  toneChipActive: { backgroundColor: colors.accentDim, borderColor: "rgba(255,61,0,0.4)" },
  toneText: { fontSize: 13, color: colors.textMuted },
  toneTextActive: { color: "#ff7050" },
  summary: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md },
  summaryText: { fontSize: 13, color: colors.textMuted },
  summaryBold: { color: colors.text, fontWeight: "700" },
  progressBox: { marginBottom: spacing.md },
  progressBar: { backgroundColor: colors.surface, borderRadius: 3, height: 3, overflow: "hidden", marginBottom: 8 },
  progressFill: { height: "100%", backgroundColor: colors.accent, borderRadius: 3 },
  progressLabel: { fontSize: 11, color: colors.textDim, fontFamily: "monospace" },
  cta: { backgroundColor: colors.accent, borderRadius: radius.md, paddingVertical: 18, alignItems: "center" },
  ctaDisabled: { backgroundColor: "#1a1a1a" },
  ctaText: { color: "#fff", fontSize: 15, fontWeight: "700", letterSpacing: 1 },
});
